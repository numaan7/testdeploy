from flask import Flask, request, jsonify, render_template, send_file
import openai
from pptx import Presentation
from io import BytesIO

app = Flask(__name__)
openai.api_key = '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'

# All static pages
@app.route('/')
def serve_html():
    return render_template('Index.html')

@app.route('/color-palette-generator')
def color_palette_generator():
    return render_template('ColorPalletteGeneration.html')

@app.route('/color-palette-generator1')
def color_palette_generator1():
    return render_template('Color-PalletteGeneration1.html')

@app.route('/color-palette-generator2')
def color_palette_generator2():
    return render_template('Colour Palette Generator2 - Display.html')

@app.route('/color-palette-generator3')
def color_palette_generator3():
    return render_template('Colour Palette Generator3.html')

@app.route('/image-gallery')
def image_gallery():
    return render_template('ImageGallery.html')

@app.route('/investigative-practice')
def investpractice():
    return render_template('Investigativepractise.html')

@app.route('/investigative-reports-generator')
def investrepo():
    return render_template('Investigative Reports Generator.html')

@app.route('/investigative-reports')
def investrepos():
    return render_template('InvestigativeReports.html')

@app.route('/presentation-generator')
def presentation_generator():
    return render_template('presentation-generator.html')

@app.route('/presentation-generator2')
def presentation_generator2():
    return render_template('PresentationGenerator2.html')

@app.route('/presentation-generator3')
def presentation_generator3():
    return render_template('PresentationGenerator3-Editor.html')

@app.route('/presentation-generator1')
def presentation_generator1():
    return render_template('PresentationGnerator1.html')

@app.route('/tenday')
def tenday():
    return render_template('10-DayTrial2.html')

@app.route('/tendaytree')
def tendaytree():
    return render_template('10-DayTrial3.html')

@app.route('/tendayfour')
def tendayfour():
    return render_template('10-DayTrial4.html')

@app.route('/tendayfive')
def tendayfive():
    return render_template('10-DayTrial5.html')


@app.route('/pricing')
def pricing():
    return render_template('pricing.html')

@app.route('/about')
def about():
    return render_template('About.html')

@app.route('/contact')
def contact():
    return render_template('Contact.html')

@app.route('/privacypol')
def privacypol():
    return render_template('PrivacyPolicy.html')

@app.route('/termscond')
def termscond():
    return render_template('Termsandconditions.html')


@app.route('/standard-plan-checkout')
def standard_plan_checkout():
    return render_template('Standrad Plan Checkout.html')

@app.route('/premium-plan-checkout')
def premium_plan_checkout():
    return render_template('Premium Plan Checkout.html')

@app.route('/basic-plan-checkout')
def basic_plan_checkout():
    return render_template('Basic Plan Checkout.html')

@app.route('/whistleblower')
def whistle_blower():
    return render_template('whistleblowerbot.html')

@app.route('/dashboard')
def dashboard():
    return render_template('308-GPT - Dashboard.html')

@app.route('/ai-imagegenerator1')
def ai_imagegenerator1():
    return render_template('AI Image Generator1.html')

@app.route('/ai-imagegenerator2')
def ai_imagegenerator2():
    return render_template('AI Image Generator2.html')

@app.route('/authentication')
def auth():
    return render_template('Authentication.html')


@app.route('/authentication1')
def auth1():
    return render_template('Authentication1.html')


@app.route('/authentication2')
def auth2():
    return render_template('Authentication2.html')


@app.route('/authentication3')
def auth3():
    return render_template('Authentication3.html')


@app.route('/authentication4')
def auth4():
    return render_template('Authentication4.html')


@app.route('/authentication5')
def auth5():
    return render_template('Authentication5.html')

@app.route('/blog-generator1')
def blog1():
    return render_template('BlogGenerator1.html')

@app.route('/blog-generator2')
def blog2():
    return render_template('BlogGenerator2-SEO.html')

@app.route('/blog-generator3')
def blog3():
    return render_template('BlogGenerator3-Editor.html')

@app.route('/business-budget-analysis')
def business_budget():
    return render_template('Business Budget Analysis.html')

@app.route('/image-generator')
def image_generator():
    return render_template('image-generator.html')

@app.route('/make-blog-posts')
def make_blog_posts():
    return render_template('make-blog-posts.html')

@app.route('/retirement-planning-bot')
def retirement():
    return render_template('Retirement Planning Bot.html')

@app.route('/aichatassistant')
def aichatassistant():
    return render_template('AIchatAssistant.html')

@app.route('/aichatinterface')
def aichatinterface():
    return render_template('AIchatInterface.html')



# All apis
@app.route('/api/investigative-practice', methods=['POST'])
def investigative_practice():
    # Get the JSON data from the request
    data = request.get_json()
    
    # Extract relevant information from the JSON data
    complaint_type = data.get("complaint-type")
    workplace_location = data.get("workplace-location")
    situation_details = data.get("situation-details")
    consulted_legislation = data.get("consulted-legislation")
    
    # Construct a prompt for ChatGPT based on the extracted information
    prompt = f"Complaint type: {complaint_type}\nWorkplace location: {workplace_location}\nSituation details: {situation_details}\nConsulted legislation: {consulted_legislation}\n"
    
    # Use ChatGPT to generate a response
    response = openai.Completion.create(
        engine="text-davinci-002",  # You can use a different engine if needed
        prompt=prompt,
        max_tokens=100,  # Adjust the maximum number of tokens in the response as needed
    )
    
    # Extract the generated answer from the ChatGPT response
    answer = response.choices[0].text
    
    # Construct the response JSON
    response_data = {
        "message": "Data received and processed successfully",
        "answer": answer
    }
    
    return jsonify(response_data)


@app.route('/api/whistleblower', methods=['POST'])
def whistleblower():
    # Get the JSON data from the request
    data = request.get_json()
    
    # Extract relevant information from the JSON data
    complaint_type = data.get("complaint-type")
    incident_details = data.get("incident-details")
    reported_to = data.get("reported-to")
    other_witnesses = data.get("other-witnesses")
    retaliation_threats = data.get("retaliation-threats")
    anonymous_contact = data.get("anonymous-contact")
    physical_contact = data.get("physical-contact")
    witnesses = data.get("witnesses")
    reported_incident = data.get("reported-incident")
    similar_incident = data.get("similar-incident")
    action_taken = data.get("action-taken")
    feeling_safe = data.get("feeling-safe")
    
    # Construct a prompt for ChatGPT based on the extracted information
    prompt = f"Complaint type: {complaint_type}\nIncident Details: {incident_details}\nReported to: {reported_to}\nOther witnesses: {other_witnesses}\nRetaliation threats: {retaliation_threats}\nAnonymous contact: {anonymous_contact}\nPhysical contact: {physical_contact}\nWitnesses: {witnesses}\nReported incident: {reported_incident}\nSimilar incident: {similar_incident}\nAction taken: {action_taken}\nFeeling safe: {feeling_safe}\n"
    
    # Use ChatGPT to generate a response
    response = openai.Completion.create(
        engine="text-davinci-002",  # You can use a different engine if needed
        prompt=prompt,
        max_tokens=100,  # Adjust the maximum number of tokens in the response as needed
    )
    
    # Extract the generated answer from the ChatGPT response
    answer = response.choices[0].text
    
    # Construct the response JSON
    response_data = {
        "message": "Data received and processed successfully",
        "answer": answer
    }
    
    return jsonify(response_data)



@app.route('/api/retirement-plan', methods=['POST'])
def retirement_planning():
    # Get the JSON data from the request
    data = request.get_json()
    
    # Extract relevant information from the JSON data
    age = data.get("age")
    current_income = data.get("current-income")
    partner_income = data.get("partner-income")
    other_income = data.get("other-income")
    outstanding_debts = data.get("outstanding-debts")
    current_debt = data.get("current-debt")
    debt_types = data.get("debt-types")
    debt_interest_rate = data.get("debt-interest-rate")
    home_status = data.get("home-status")
    home_value = data.get("home-value")
    mortgage_balance = data.get("mortgage-balance")
    home_equity = data.get("home-equity")
    investment_portfolio = data.get("investment-portfolio")
    current_age_retirement_age = data.get("current-age-retirement-age")
    current_income_retirement_income = data.get("current-income-retirement-income")
    current_debt_expenses = data.get("current-debt-expenses")
    current_contribution = data.get("current-contribution")
    retirement_plan = data.get("retirement-plan")
    investment_horizon = data.get("investment-horizon")
    portfolio_value = data.get("portfolio-value")
    portfolio_investments = data.get("portfolio-investments")
    investment_return = data.get("investment-return")
    risk_tolerance = data.get("risk-tolerance")
    estimated_retirement_age = data.get("estimated-retirement-age")
    health_status = data.get("health-status")
    dependents = data.get("dependents")
    
    # Construct a prompt for ChatGPT based on the extracted information
    prompt = f"Age: {age}\nCurrent Income: {current_income}\nPartner Income: {partner_income}\nOther Income: {other_income}\nOutstanding Debts: {outstanding_debts}\nCurrent Debt: {current_debt}\nDebt Types: {debt_types}\nDebt Interest Rate: {debt_interest_rate}\nHome Status: {home_status}\nHome Value: {home_value}\nMortgage Balance: {mortgage_balance}\nHome Equity: {home_equity}\nInvestment Portfolio: {investment_portfolio}\nCurrent Age and Estimated Retirement Age: {current_age_retirement_age}\nCurrent Income and Estimated Income in Retirement: {current_income_retirement_income}\nCurrent Debt and Monthly Expenses: {current_debt_expenses}\nCurrent Monthly Contribution to Investment Portfolio: {current_contribution}\nContributing to Retirement Savings Plan: {retirement_plan}\nInvestment Horizon: {investment_horizon}\nPortfolio Value: {portfolio_value}\nPortfolio Investments: {portfolio_investments}\nInvestment Return: {investment_return}\nRisk Tolerance: {risk_tolerance}\nEstimated Retirement Age: {estimated_retirement_age}\nHealth Status: {health_status}\nDependents: {dependents}\n"
    
    # Use ChatGPT to generate a response
    response = openai.Completion.create(
        engine="text-davinci-002",  # You can use a different engine if needed
        prompt=prompt,
        max_tokens=100,  # Adjust the maximum number of tokens in the response as needed
    )
    
    # Extract the generated answer from the ChatGPT response
    answer = response.choices[0].text
    
    # Construct the response JSON
    response_data = {
        "message": "Data received and processed successfully",
        "answer": answer
    }
    
    return jsonify(response_data)


@app.route('/api/budget-questionnaire', methods=['POST'])
def budget_questionnaire():
    # Get the JSON data from the request
    data = request.get_json()
    
    # Extract relevant information from the JSON data for Operational Budget
    operational_total_budget = data.get("operational-total-budget")
    operational_expense_breakdown = data.get("operational-expense-breakdown")
    operational_budget_changes = data.get("operational-budget-changes")
    operational_revenue_projection = data.get("operational-revenue-projection")
    operational_profit_margin = data.get("operational-profit-margin")
    operational_concerns = data.get("operational-concerns")
    operational_budget_alignment = data.get("operational-budget-alignment")
    operational_timeline = data.get("operational-timeline")
    operational_regulations = data.get("operational-regulations")
    operational_budget_upload = data.get("operational-budget-upload")
    operational_budget_type = data.get("operational-budget-type")

    # Extract relevant information from the JSON data for Capital Budget
    capital_project_description = data.get("capital-project-description")
    capital_total_budget = data.get("capital-total-budget")
    capital_timeline = data.get("capital-timeline")
    capital_unforeseen_expenses = data.get("capital-unforeseen-expenses")
    capital_unforeseen_expenses_amount = data.get("capital-unforeseen-expenses-amount")
    capital_budget_adjustment = data.get("capital-budget-adjustment")
    capital_spending_status = data.get("capital-spending-status")
    capital_project_risks = data.get("capital-project-risks")
    capital_roi = data.get("capital-roi")
    capital_external_review = data.get("capital-external-review")
    capital_cost_savings = data.get("capital-cost-savings")

    # Construct a prompt for ChatGPT based on the extracted information for both budgets
    operational_prompt = f"Operational Total Budget: {operational_total_budget}\nOperational Expense Breakdown: {operational_expense_breakdown}\nOperational Budget Changes: {operational_budget_changes}\nOperational Revenue Projection: {operational_revenue_projection}\nOperational Profit Margin: {operational_profit_margin}\nOperational Concerns: {operational_concerns}\nOperational Budget Alignment: {operational_budget_alignment}\nOperational Timeline: {operational_timeline}\nOperational Regulations: {operational_regulations}\nOperational Budget Type: {operational_budget_type}\n"
    
    capital_prompt = f"Capital Project Description: {capital_project_description}\nCapital Total Budget: {capital_total_budget}\nCapital Timeline: {capital_timeline}\nCapital Unforeseen Expenses: {capital_unforeseen_expenses}\nCapital Unforeseen Expenses Amount: {capital_unforeseen_expenses_amount}\nCapital Budget Adjustment: {capital_budget_adjustment}\nCapital Spending Status: {capital_spending_status}\nCapital Project Risks: {capital_project_risks}\nCapital ROI: {capital_roi}\nCapital External Review: {capital_external_review}\nCapital Cost Savings: {capital_cost_savings}\n"
    
    # Combine both prompts
    prompt = operational_prompt + capital_prompt

    # Use ChatGPT to generate a response
    response = openai.Completion.create(
        engine="text-davinci-002",  # You can use a different engine if needed
        prompt=prompt,
        max_tokens=100,  # Adjust the maximum number of tokens in the response as needed
    )
    
    # Extract the generated answer from the ChatGPT response
    answer = response.choices[0].text
    
    # Construct the response JSON
    response_data = {
        "message": "Data received and processed successfully",
        "answer": answer
    }
    
    return jsonify(response_data)


@app.route('/api/blog-content', methods=['POST'])
def blog_content_generation():
    print("hrllo this is blog contents")
    # Get the JSON data from the request
    data = request.get_json()
    print(data)
    
    # Extract relevant information from the JSON data
    blog_title = data.get("blog-title")
    
    # Construct a prompt for ChatGPT to generate title, outline, and paragraphs
    title_prompts = [
        f"Create an attractive title for a blog about '{blog_title}' in 3-4 words",
        f"Generate a catchy blog title for '{blog_title}' in 3-4 words",
        f"Craft a meaningful and concise title for a blog on '{blog_title}' in 3-4 words"
    ]
    title = f"'{blog_title}' this is the blog title generate a titles"
    outline1 = f"'{blog_title}' this is the blog title generate a meaningfull and topic related short 50-100 words outline (Outline 1)"
    outline2 = f"'{blog_title}' this is the blog title generate a concise and topic related short 50-100 words outline (Outline 2)"
    paragraph1 = f"'{blog_title}' this is the blog title generate meaningfull and topic related 500-1000 words paragraph (Paragraph 1)"
    paragraph2 = f"'{blog_title}' this is the blog title generate a concise and topic related 500-1000 words paragraph (Paragraph 2)"

    response_image1 = openai.Image.create(prompt=title)
    response_image2 = openai.Image.create(prompt=title)

    generated_titles = []

    for title_prompt in title_prompts:
        response_title = openai.Completion.create(
            engine="text-davinci-002",  # You can use a different engine if needed
            prompt=title_prompt,
            max_tokens=15,  # Limit the title to 3-4 words
        )

        generated_title = response_title.choices[0].text.strip()
        generated_titles.append(generated_title)
 


   # Generate two outlines
    response_outline1 = openai.Completion.create(
        engine="text-davinci-002",
        prompt=outline1,
        max_tokens=1000,  # Adjust the maximum number of tokens in the response as needed
    )

    response_outline2 = openai.Completion.create(
        engine="text-davinci-002",
        prompt=outline2,
        max_tokens=1000,  # Adjust the maximum number of tokens in the response as needed
    )

 # Generate two paragraphs
    response_paragraph1 = openai.Completion.create(
        engine="text-davinci-002",
        prompt=paragraph1,
        max_tokens=1000,  # Adjust the maximum number of tokens in the response as needed
    )

    response_paragraph2 = openai.Completion.create(
        engine="text-davinci-002",
        prompt=paragraph2,
        max_tokens=1000,  # Adjust the maximum number of tokens in the response as needed
    )
    
    # Extract the generated content from the ChatGPT response
    # generated_title= response_title.choices[0].text
    generated_outline1 = response_outline1.choices[0].text
    generated_outline2 = response_outline2.choices[0].text
    generated_paragraph1 = response_paragraph1.choices[0].text
    generated_paragraph2 = response_paragraph2.choices[0].text
    
    print(generated_titles)
    # Construct the response JSON
    response_data = {
        "message": "Content generated successfully",
        "titles": generated_titles,
        "outline1": generated_outline1,
        "outline2": generated_outline2,
        "paragraph1": generated_paragraph1,
        "paragraph2": generated_paragraph2,
        "link1": response_image1.data[0].url,
        "link2": response_image2.data[0].url
        
    }
    
    return jsonify(response_data)





# @app.route('/api/ppt', methods=['POST'])
# def ppt_content_generation():
    # Get the JSON data from the request
    # print("hello printed")
    # data = request.get_json()
    
    # # Extract relevant information from the JSON data
    # presentation_title = data.get("presentation-title")
    # presentation_description = data.get("presentation-description")
    # slide_count = data.get("slide-count")

    # presentation = Presentation()

    # # Initialize an empty list to store slide data
    # slide_data = []

    # # Loop to generate slides
    # for i in range(slide_count):
    # # Generate a title using ChatGPT
    #     title_input = f"'{presentation_title}' this is the blog title generate a seo title"
    #     response_title = openai.Completion.create(
    #         engine="text-davinci-002",  # You can use a different engine if needed
    #         prompt=title_input,
    #         max_tokens=1000,  # Adjust the maximum number of tokens in the response as needed
    #     )
    #     generated_title = response_title.choices[0].text.strip()

    #     # Generate a description using ChatGPT
    #     des_input = f"'{generated_title}' this is the topic give me some description "
    #     response_des = openai.Completion.create(
    #         engine="text-davinci-002",  # You can use a different engine if needed
    #         prompt=des_input,
    #         max_tokens=1000,  # Adjust temperature
    #     )
    #     generated_des = response_des.choices[0].text.strip()       # Add slide data to the list
    #     response_image = openai.Image.create(prompt=generated_title)
    #     slide_data.append({
    #         "title": generated_title,
    #         "description": generated_des,
    #         "link": response_image.data[0].url
    #     })
    #     slide = presentation.slides.add_slide(presentation.slide_layouts[5])
    #     title = slide.shapes.title
    #     title.text = generated_title

    #     content = slide.shapes.add_textbox(left=40, top=80, width=560, height=400)
    #     content.text = generated_des

    # local_file_path = f"{presentation_title}.pptx"
    # presentation.save(local_file_path)
    # # Construct the response JSON
    # response_data = {
    #     "message": "Content generated successfully",
    #     "data": slide_data,
    #     "local_file_path": local_file_path
    # }
    
    # return jsonify(response_data)
   
from flask import Flask, send_file, request, jsonify
from io import BytesIO
from pptx import Presentation
from pptx.util import Inches,Pt  
import requests
import tempfile
import os
from dotenv import load_dotenv

# @app.route('/api/ppt', methods=['POST'])
# def ppt_content_generation():
#     # Get the JSON data from the request
#     data = request.get_json()
    
#     # Extract relevant information from the JSON data
#     presentation_title = data.get("presentation-title")
#     presentation_description = data.get("presentation-description")
#     slide_count = data.get("slide-count")

#     presentation = Presentation()

#     for i in range(slide_count):
#         # Generate a title using ChatGPT
#         title_input = f"Create a concise title for a slide in the presentation about '{presentation_title}'"
#         response_title = openai.Completion.create(
#             engine="text-davinci-002",
#             prompt=title_input,
#             max_tokens=15
#         )

#         generated_title = response_title.choices[0].text.strip()

#         # Generate a short description using ChatGPT with "in English" in the prompt
#         description_input = f"Generate a professional brief description for the slide about '{generated_title}' in English. {presentation_description}"
#         response_description = openai.Completion.create(
#             engine="text-davinci-002",
#             prompt=description_input,
#             max_tokens=100  # Limit to a more concise description
#         )
#         generated_description = response_description.choices[0].text.strip()

#         # Generate an image using DALL-E
#         image_prompt = f" '{generated_title}'"
#         response_image = openai.Image.create(prompt=image_prompt)

#         # Get the image URL
#         image_url = response_image['data'][0]['url']

#         # Add a slide
#         slide = presentation.slides.add_slide(presentation.slide_layouts[5])
        
#         # Add title to the slide
#         title = slide.shapes.title
#         title.text = generated_title

#         # Add a description text box to the slide within the slide margin
#         left = Inches(0.5)  # Adjust the left position to place it within the slide content area
#         top = Inches(1.5)
#         width = Inches(2)
#         height = Inches(4.5)
#         text_box = slide.shapes.add_textbox(left, top, width, height)
#         text_frame = text_box.text_frame

#         # Add the generated description as a single paragraph
#         p = text_frame.add_paragraph()
#         p.text = generated_description

#         # Download the image using requests
#         response = requests.get(image_url)

#         # Add the image to the slide
#         image_data = response.content
#         img = BytesIO(image_data)
#         left = Inches(5.5)  # Position the image to the right of the description
#         top = Inches(1.5)   # Adjust the position as needed
#         width = Inches(3.5)  # Adjust the size as needed
#         height = Inches(3.5)
#         slide.shapes.add_picture(img, left, top, width, height)

   
#     # Create a temporary directory to store the presentation
#     with tempfile.TemporaryDirectory() as temp_dir:
#         temp_file_path = os.path.join(temp_dir, f"{presentation_title}.pptx")

#         # Save the presentation to the temporary file path
#         presentation.save(temp_file_path)

#         # Save the presentation to a BytesIO object
#         presentation_data = BytesIO()
#         presentation.save(presentation_data)

#         # Reset the position of the BytesIO object
#         presentation_data.seek(0)

#         # Return the presentation as an attachment
#         return send_file(presentation_data, as_attachment=True, download_name=f"{presentation_title}.pptx")










# Define the temp_dir at a higher scope
temp_dir = tempfile.gettempdir()

@app.route('/api/download_ppt', methods=['GET'])
def download_ppt():
    # Get the file name from the query parameter
    file_name = request.args.get("file")

    # Set the file path to the temporary directory
    file_path = os.path.join(temp_dir, f"{file_name}.pptx")

    # Check if the file exists
    if os.path.exists(file_path):
        # Send the file as a response to the client
        return send_file(file_path, as_attachment=True)
    else:
        return "File not found", 404


# define the chat bot
@app.route("/chatbot", methods =["POST"])
def chatbot():

    user_input= request.form["message"]

    prompt = f"User: {user_input}\nChatbot: "

    chat_history =[]

    responce=openai.Completion.create(
        engine="text-davinci-002",
        prompt=prompt,
        temperature=0.5,
        max_tokens=60,
        top_p=1,
        frequency_penalty=0,
        stop=["\nUser: ", "\nChatbot"]

    )

    bot_responce = responce.choices[0].text.strip()

    chat_history.append(f"User: {user_input}\nChatbot: {bot_responce}")



    print(bot_responce)
    return render_template(
        "AIchatInterface.html",
        user_input=user_input,
        bot_responce=bot_responce,
    )




# @app.route('/api/download-ppt/<filename>', methods=['GET'])
# def download_ppt(filename):
#     try:
#         return send_file(filename, as_attachment=True)
#     except Exception as e:
#         return str(e)



@app.route('/api/seo-optimization', methods=['POST'])
def seo_optimization():
    # Get the JSON data from the request
    data = request.get_json()
    
    # Extract relevant information from the JSON data
    meta_title = data.get("meta-title")
    meta_description = data.get("meta-description")
    keywords = data.get("keywords")
    
    # Construct a prompt for ChatGPT based on the extracted information
    sugges = f"Meta Title: {meta_title}\nMeta Description: {meta_description}\nKeywords: {keywords}\n  give me seo suggestions"
    opti = f"Meta Title: {meta_title}\nMeta Description: {meta_description}\nKeywords: {keywords}\n  give me seo optimized content preview"
    chan = f"Meta Title: {meta_title}\nMeta Description: {meta_description}\nKeywords: {keywords}\n  give me Changes Made for SEO Optimization:"

    # Use ChatGPT to generate SEO suggestions
    response_seo = openai.Completion.create(
        engine="text-davinci-002",  # You can use a different engine if needed
        prompt=sugges,
        max_tokens=100,  # Adjust the maximum number of tokens in the response as needed
    )

    response_opti = openai.Completion.create(
        engine="text-davinci-002",  # You can use a different engine if needed
        prompt=opti,
        max_tokens=100,  # Adjust the maximum number of tokens in the response as needed
    )
    response_chan = openai.Completion.create(
        engine="text-davinci-002",  # You can use a different engine if needed
        prompt=chan,
        max_tokens=100,  # Adjust the maximum number of tokens in the response as needed
    )
    
    # Extract the generated SEO suggestions from the ChatGPT response
    seo_suggestions = response_seo.choices[0].text
    opti_suggestions = response_opti.choices[0].text
    chan_suggestions = response_chan.choices[0].text
    
    # Construct the response JSON
    response_data = {
        "message": "SEO optimization completed successfully",
        "seo_suggestions": seo_suggestions,
        "optimized": opti_suggestions,
        "changes": chan_suggestions,
    }
    
    return jsonify(response_data)

@app.route('/api/ai-image-generator', methods=['POST'])
def ai_image_generator():
    # Get the JSON data from the request
    print("image genarated function is fired")
    data = request.get_json()
    
    # Extract relevant information from the JSON data
    prompt = data.get("prompt")
    style = data.get("style")
    quantity = data.get("quantity")
    size = data.get("size")
    
    print(data)


     # Use ChatGPT to generate SEO suggestions
       # Use ChatGPT to generate an image
    response = openai.Image.create(
        prompt=prompt,
        n=int(quantity),  # Use 'n' instead of 'quantity' to generate a single image
        size=size
    )
    
    
  # Extract all the generated image URLs from the ChatGPT response
    image_urls = [item.url for item in response.data]

    # Construct the response JSON
    response_data = {
        "message": "Image generation completed successfully",
        "links": image_urls
    }

    
    print(response_data)
    



    return jsonify(response_data)



if __name__ == '__main__':
    app.run(host='0.0.0.0')
